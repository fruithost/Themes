# Changelog
## `1.0.0` - 24.09.2024
Implement the basic theme.